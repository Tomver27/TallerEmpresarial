/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tomas.model;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author tomas
 */
@Stateless
public class EstudianteDao implements EstudianteDaoLocal {
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public void addEstudiante(Estudiante estudiante) {
        em.persist(estudiante);
    }

    @Override
    public void editEstudiante(Estudiante estudiante) {
        em.merge(estudiante);
    }

    @Override
    public void deleteEstudiante(int estudianteId) {
        em.remove(getEstudiante(estudianteId));
    }
    
    @Override
    public Estudiante getEstudiante(int estudianteId) {
        return em.find(Estudiante.class, estudianteId);
    }

    @Override
    public List<Estudiante> getAllEstudiantes() {
        return em.createNamedQuery("Estudiante.getAll").getResultList();
    }

    

    
    
    
}
